Must set up server before use


This program uses the 'requests' and 'spotipy' librabies
These files are given in the zip file, 
Please extract them to the main folder
Or
Import them using pip. 
For example:
	'py -m pip install spotipy'


Instructions
- open cmd line
- cd to this folder
- type 'py -m http.server 8000'

Spotify Credentials
username: 16629429@students.lincoln.ac.uk
password: Group8Group8